package dao;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.jasypt.util.password.ConfigurablePasswordEncryptor;

import beans.Utilisateur;



@Stateless
public class UtilisateurDao 
{
	public static final	 String ALGO_CHIFFREMENT 		=	"SHA-256";
	private static final String JPQL_SELECT_PAR_EMAIL 	= 	"SELECT u FROM Utilisateur u WHERE u.email=:email";
	private static final String JPQL_SELECT_ALL_PAYS 	= 	"SELECT p.nom FROM Pays p";
	private static final String PARAM_EMAIL 			= 	"email";

	// Injection du manager, qui s'occupe de la connexion avec la BDD
	@PersistenceContext( unitName = "sunny_bdd_PU" )
	private EntityManager em;
	
	
	// Enregistrement d'un nouvel utilisateur
	public void creer( Utilisateur utilisateur ) throws DAOException
	{
		try {
			em.persist( utilisateur );
		} catch ( Exception e ) 
		{
			utilisateur.setMotDePasse("");
			throw new DAOException( e );
		}
	}
	
	// Recherche d'un utilisateur � partir de son adresse email
	public Utilisateur trouver( String email ) throws DAOException 
	{
		Utilisateur utilisateur = null;
		Query requete = em.createQuery( JPQL_SELECT_PAR_EMAIL );
		requete.setParameter( PARAM_EMAIL, email );
		try {
			utilisateur = (Utilisateur) requete.getSingleResult();
		} catch ( NoResultException e ) {
			return null;
		} catch ( Exception e ) {
			throw new DAOException( e );
		}
		
		return utilisateur;
	}

	public Utilisateur connexion(String email, String motDePasse)
	{
		Utilisateur utilisateur = trouver(email);

		if (utilisateur != null)
		{
			ConfigurablePasswordEncryptor passwordEncryptor = new ConfigurablePasswordEncryptor();
			passwordEncryptor.setAlgorithm( ALGO_CHIFFREMENT );
			passwordEncryptor.setPlainDigest( false );
			
			if (passwordEncryptor.checkPassword(motDePasse, utilisateur.getMotDePasse()))
				return utilisateur;
			else
				return null;
		}
		else
			return null;
	}
	
	public List<String> listePays()
	{
		Query requete = em.createQuery( JPQL_SELECT_ALL_PAYS );
		
		List<String> liste = new ArrayList<String>();
		
		try {
			liste = requete.getResultList();
		} catch ( NoResultException e ) {
			return null;
		} catch ( Exception e ) {
			throw new DAOException( e );
		}
		
		return liste;
	}
}