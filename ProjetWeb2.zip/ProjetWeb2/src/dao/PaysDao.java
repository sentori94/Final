package dao;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;


@Stateless
public class PaysDao 
{
	private static final String JPQL_SELECT_ALL_PAYS = "SELECT p.nom FROM Pays p";
	
	// Injection du manager, qui s'occupe de la connexion avec la BDD
	@PersistenceContext( unitName = "sunny_bdd_PU" )
	private EntityManager em;

	// Extraire Liste des Pays
	public List<String> extrairePays( ) throws DAOException 
	{
		Query requete = em.createQuery( JPQL_SELECT_ALL_PAYS );
		
		List<String> liste = new ArrayList<String>();
		try {
			liste = requete.getResultList();
		} catch ( NoResultException e ) {
			return null;
		} catch ( Exception e ) {
			throw new DAOException( e );
		}

		return liste;
	}
}
