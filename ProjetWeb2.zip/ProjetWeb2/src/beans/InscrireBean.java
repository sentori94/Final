package beans;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.context.FacesContext;

import org.jasypt.util.password.ConfigurablePasswordEncryptor;

import dao.PaysDao;
import dao.UtilisateurDao;

@ManagedBean
@RequestScoped
public class InscrireBean implements Serializable 
{
	public static final	 String ALGO_CHIFFREMENT 		=	"SHA-256";

	private static final long serialVersionUID = 1L;
	private Utilisateur utilisateur;
	private List<String> listePays = new ArrayList<String>();

	// Injection de notre EJB (Session Bean Stateless)
	@EJB
	private UtilisateurDao utilisateurDao;
	
	@EJB
	private PaysDao paysDao;
	
	// Initialisation de l'entit� utilisateur
	public InscrireBean() 
	{
		utilisateur = new Utilisateur();
		listePays = utilisateurDao.listePays();
	}
	
	// M�thode d'action appel�e lors du clic sur le bouton du formulaire d'inscription
	public void inscrire() 
	{
		initialiserDateInscription();
		chiffrerMDP();
		utilisateurDao.creer( utilisateur );
		FacesMessage message = new FacesMessage( "Succ�s de l'inscription !" );
		FacesContext.getCurrentInstance().addMessage( null, message);
	}
	
	public Utilisateur getUtilisateur() 
	{
		return utilisateur;
	}
	
	public List<String> getListePays() {
		return listePays;
	}

	public void setListePays(List<String> listePays) {
		this.listePays = listePays;
	}

	private void initialiserDateInscription() {
		Timestamp date = new Timestamp( System.currentTimeMillis());
		utilisateur.setDateInscription( date );
	}
	
	private void chiffrerMDP()
	{
		/*
		 * Utilisation de la biblioth�que Jasypt pour chiffrer le mot de passe
		 * efficacement.
		 *
		 * L'algorithme SHA-256 est ici utilis�, avec par d�faut un salage
		 * al�atoire et un grand nombre d'it�rations de la fonction de hashage.
		 *
		 * La String retourn�e est de longueur 56 et contient le hash en Base64.
		 */
		ConfigurablePasswordEncryptor passwordEncryptor = new ConfigurablePasswordEncryptor();
		passwordEncryptor.setAlgorithm( ALGO_CHIFFREMENT );
		passwordEncryptor.setPlainDigest( false );
		String motDePasseChiffre = passwordEncryptor.encryptPassword( utilisateur.getMotDePasse());
		utilisateur.setMotDePasse( motDePasseChiffre );
	}
}