package beans;

import java.sql.Timestamp;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;


@Entity
@Table(name = "utilisateur")
public class Utilisateur 
{
	@Id
	@GeneratedValue( strategy = GenerationType.IDENTITY )
	private		Long		id;
	
	@Column( name = "nom" )
	@NotNull( message = "Veuillez saisir votre Nom" )
	@Size( min = 3, message = "Le nom doit contenir au moins 3 caract�res")
	private 	String 		nom;
	
	@Column( name = "prenom" )
	@NotNull( message = "Veuillez saisir votre Pr�nom" )
	private 	String 		prenom;
	
	@Column( name = "pseudo" )
	@NotNull( message = "Veuillez saisir votre Pseudo" )
	private 	String 		pseudo;
	
	@Column( name = "email" )
	@NotNull( message = "Veuillez saisir votre Adresse mail" )
	@Pattern( regexp = "([^.@]+)(\\.[^.@]+)*@([^.@]+\\.)+([^.@]+)", message = "Merci de saisir une adresse mail valide" )
	private		String		email;
	
	@Column( name = "mot_de_passe" )
	@NotNull( message = "Veuillez saisir votre Mot de Passe" )
	@Size( min = 3, message = "Le mot de passe doit contenir au moins 3 caract�res")
	@Pattern(regexp = ".*(?=.{8,})(?=.*\\d)(?=.*[a-z])(?=.*[A-Z]).*", message = "Le mot de passe saisi n'est pas assez s�curis�")
	private 	String 		motDePasse;
	
	@Column( name = "pays" )
	@NotNull( message = "Veuillez choisir un pays" )
	private 	String 		pays;
	
	@Column( name = "date_naissance" )
	@NotNull( message = "Veuillez choisir une date de naissance" )
	private 	String 	dateNaissance;
	
	@Column( name = "date_inscription" )
	private		Timestamp	dateInscription;
	
	public Utilisateur()
	{
		
	}
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public String getPrenom() {
		return prenom;
	}
	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}
	public String getPseudo() {
		return pseudo;
	}
	public void setPseudo(String pseudo) {
		this.pseudo = pseudo;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getMotDePasse() {
		return motDePasse;
	}
	public void setMotDePasse(String motDePasse) {
		this.motDePasse = motDePasse;
	}
	public String getPays() {
		return pays;
	}
	public void setPays(String pays) {
		this.pays = pays;
	}
	public Timestamp getDateInscription() {
		return dateInscription;
	}
	public void setDateInscription(Timestamp dateInscription) {
		this.dateInscription = dateInscription;
	}

	public String getDateNaissance() {
		return dateNaissance;
	}

	public void setDateNaissance(String dateNaissance) {
		this.dateNaissance = dateNaissance;
	}
}
