$(function() {
	/*
  // La vid�o �tant lanc�e automatiquement, le bouton est masqu�
   $('#play_pause').hide();
	*/
	
   // Assignation de l'�l�ment <video>
   la_video = $('#video').get(0);

   // Le clic Bouton lance la lecture...
   $('#play_pause').click(function() {
   // ...si le bouton est visible (donc vid�o en pause)
	   if ($(this).is(':visible')) {
		   $(this).fadeOut("normal", function() {
			   // Au masquage du bouton, on enl�ve la class qui affiche l'image Pause
			   $(this).removeClass('pause');
		   });
		  la_video.play();
		  //la_video.attr('controls','controls');
		   la_video.setAttribute("controls","controls");


	   }
   });
  

   // Clic sur vid�o = Pause + affichage du bouton
	   $('#video').click(function() 
	   {
		   la_video.pause();
		   // on ajoute la class qui affiche l'image Pause
		   $('#play_pause').addClass('pause').fadeIn("normal");
	   });

   // En fin de lecture, on affiche le bouton en image Lecture
   // pour pouvoir relancer la lecture
   la_video.onended = function() {
	   la_video.load();
	   video.removeAttribute("controls");
	   $('#play_pause').fadeIn("normal");
   }
});
